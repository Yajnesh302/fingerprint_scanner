<%@ Page Title="Enroll" Language="C#" AutoEventWireup="true" CodeBehind="Enroll.aspx.cs" Inherits="MantraOfflineFingerprint.Enroll" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Enroll Fingerprint</title>
</head>
<body style="font-family:Segoe UI, Arial; max-width:480px; margin:60px auto;">
    <form id="form1" runat="server">
        <h2>Enroll a new fingerprint</h2>

        <p>
            <asp:Label runat="server" AssociatedControlID="txtName">Name:</asp:Label><br />
            <asp:TextBox ID="txtName" runat="server" Width="300px" />
            <asp:RequiredFieldValidator runat="server" ControlToValidate="txtName"
                ErrorMessage="Please enter a name" Display="Dynamic" ForeColor="Red" />
        </p>

        <p>
            <asp:Button ID="btnCapture" runat="server" Text="Place finger and Capture"
                OnClick="btnCapture_Click" />
        </p>

        <asp:Label ID="lblStatus" runat="server" Font-Bold="true" />

        <hr />
        <h3>Enrolled users</h3>
        <asp:GridView ID="gvUsers" runat="server" AutoGenerateColumns="false" >
            <Columns>
                <asp:BoundField DataField="Id" HeaderText="Id" />
                <asp:BoundField DataField="Name" HeaderText="Name" />
                <asp:BoundField DataField="EnrolledOn" HeaderText="Enrolled On" DataFormatString="{0:g}" />
            </Columns>
        </asp:GridView>

        <p><a href="Verify.aspx">Go to Verify page &raquo;</a></p>
    </form>
</body>
</html>
