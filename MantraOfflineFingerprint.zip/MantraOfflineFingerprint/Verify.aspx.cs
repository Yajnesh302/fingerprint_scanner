using System;
using System.Drawing;

namespace MantraOfflineFingerprint
{
    public partial class Verify : System.Web.UI.Page
    {
        // Tune this after a few real test captures — place the SAME finger twice
        // and see what score you get vs. placing a DIFFERENT finger, then set the
        // threshold roughly halfway between "same finger" and "different finger" scores.
        private const int MatchThreshold = 60;

        protected void btnVerify_Click(object sender, EventArgs e)
        {
            try
            {
                var enrolledUsers = FingerprintStore.GetAllUsers();
                if (enrolledUsers.Count == 0)
                {
                    lblResult.ForeColor = Color.OrangeRed;
                    lblResult.Text = "No one is enrolled yet.";
                    return;
                }

                using (var device = new MantraDevice())
                {
                    var capture = device.Capture(timeoutSeconds: 10);
                    if (!capture.Success)
                    {
                        lblResult.ForeColor = Color.Red;
                        lblResult.Text = "Capture failed: " + capture.ErrorMessage;
                        return;
                    }

                    FingerprintUser bestMatch = null;
                    int bestScore = -1;

                    foreach (var user in enrolledUsers)
                    {
                        int score = device.MatchScore(capture.Template, user.Template);
                        if (score > bestScore)
                        {
                            bestScore = score;
                            bestMatch = user;
                        }
                    }

                    if (bestMatch != null && bestScore >= MatchThreshold)
                    {
                        lblResult.ForeColor = Color.Green;
                        lblResult.Text = string.Format(
                            "Matched: {0} (score {1})", bestMatch.Name, bestScore);
                    }
                    else
                    {
                        lblResult.ForeColor = Color.Red;
                        lblResult.Text = string.Format(
                            "Not recognized (best score {0}, below threshold {1})",
                            bestScore, MatchThreshold);
                    }
                }
            }
            catch (Exception ex)
            {
                lblResult.ForeColor = Color.Red;
                lblResult.Text = "Error: " + ex.Message;
            }
        }
    }
}
