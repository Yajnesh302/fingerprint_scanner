using System;
// TODO: confirm this matches your DLL. Common namespaces are either
// "MFS100Wrapper" or "Mantra.Mfs100" — check by adding the reference in
// Visual Studio and typing "using Mantra" / "using MFS100" to see what
// IntelliSense offers.
using MFS100Wrapper;

namespace MantraOfflineFingerprint
{
    /// <summary>
    /// Result of a single capture attempt, in our own app's terms —
    /// isolates the rest of the app from the raw SDK types.
    /// </summary>
    public class CaptureResult
    {
        public bool Success { get; set; }
        public string ErrorMessage { get; set; }
        public byte[] Template { get; set; }
        public int Quality { get; set; }
    }

    /// <summary>
    /// Thin wrapper around the Mantra MFS100 SDK. This isolates the two
    /// or three calls that vary between SDK versions so the rest of the
    /// app (Enroll.aspx, Verify.aspx) never has to touch the SDK directly.
    ///
    /// Use one instance per capture, then Dispose() — don't keep a device
    /// open across page requests, since IIS may recycle/reuse threads.
    /// </summary>
    public class MantraDevice : IDisposable
    {
        private readonly MFS100 _device;

        public MantraDevice()
        {
            _device = new MFS100();
            int rc = _device.Init();
            if (rc != 0)
                throw new InvalidOperationException(
                    "MFS100 Init() failed with code " + rc +
                    ". Check the scanner is plugged in and the Mantra client service is running.");
        }

        /// <summary>
        /// Blocking capture call — waits for a finger to be placed, or times out.
        /// </summary>
        /// <param name="timeoutSeconds">How long to wait for a finger before giving up.</param>
        public CaptureResult Capture(int timeoutSeconds = 10)
        {
            var result = new CaptureResult();
            try
            {
                // TODO: This is the #1 call likely to need adjusting for your exact
                // SDK version. Common shapes seen across MFS100 SDK releases:
                //
                //   CaptureOption opt = new CaptureOption { Timeout = timeoutSeconds, Quality = 60 };
                //   int rc = _device.CaptureFinger(opt, out CaptureData data);
                //
                // or an event-based AutoCapture() that raises an OnCaptureCompleted event
                // with a CaptureEventArgs carrying e.ISOTemplateData / e.IsoTemplate / etc.
                //
                // Check the sample project bundled with your SDK zip, or decompile
                // MFS100Wrapper.dll (ILSpy/dotPeek) to see the exact signature, then
                // replace the block below with the matching call.

                CaptureData data = new CaptureData();
                int rc = _device.CaptureFinger(timeoutSeconds, out data);

                if (rc != 0)
                {
                    result.Success = false;
                    result.ErrorMessage = "Capture failed with code " + rc;
                    return result;
                }

                result.Success = true;
                result.Template = data.IsoTemplate;   // TODO: rename to match your DLL's property
                result.Quality = data.Quality;         // TODO: rename to match your DLL's property
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        /// <summary>
        /// Compares two templates and returns a similarity score.
        /// Higher = more similar. Exact scale (0-100 vs 0-1000) depends on your SDK —
        /// run a few real captures of the same finger and different fingers to see
        /// what range your scanner returns, then tune MatchThreshold in Verify.aspx.cs.
        /// </summary>
        public int MatchScore(byte[] templateA, byte[] templateB)
        {
            // TODO: confirm the exact method name — commonly "MatchFinger",
            // "MatchScore", or "Verify" depending on SDK version.
            int score = 0;
            int rc = _device.MatchFinger(templateA, templateB, out score);
            if (rc != 0)
                return 0;
            return score;
        }

        public void Dispose()
        {
            try { _device?.Uninit(); } catch { /* ignore on shutdown */ }
        }
    }
}
