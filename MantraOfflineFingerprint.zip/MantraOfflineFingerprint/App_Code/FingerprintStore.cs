using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using LiteDB;

namespace MantraOfflineFingerprint
{
    /// <summary>
    /// All storage happens in a single local file: App_Data\fingerprints.db.
    /// No server, no network, no internet — LiteDB is an embedded, file-based database.
    /// </summary>
    public static class FingerprintStore
    {
        private static string DbPath
        {
            get { return HttpContext.Current.Server.MapPath("~/App_Data/fingerprints.db"); }
        }

        private static void EnsureDataFolder()
        {
            var dir = Path.GetDirectoryName(DbPath);
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);
        }

        public static void SaveUser(string name, byte[] template)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name is required.");
            if (template == null || template.Length == 0)
                throw new ArgumentException("Fingerprint template is empty.");

            EnsureDataFolder();
            using (var db = new LiteDatabase(DbPath))
            {
                var col = db.GetCollection<FingerprintUser>("users");
                col.Insert(new FingerprintUser
                {
                    Name = name.Trim(),
                    Template = template,
                    EnrolledOn = DateTime.Now
                });
            }
        }

        public static List<FingerprintUser> GetAllUsers()
        {
            EnsureDataFolder();
            using (var db = new LiteDatabase(DbPath))
            {
                var col = db.GetCollection<FingerprintUser>("users");
                return col.FindAll().ToList();
            }
        }

        public static void DeleteUser(int id)
        {
            EnsureDataFolder();
            using (var db = new LiteDatabase(DbPath))
            {
                var col = db.GetCollection<FingerprintUser>("users");
                col.Delete(id);
            }
        }
    }
}
