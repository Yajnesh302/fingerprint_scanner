using System;

namespace MantraOfflineFingerprint
{
    /// <summary>
    /// One enrolled person: a name plus their stored fingerprint template.
    /// The Template is whatever byte[] the Mantra SDK's capture call gives you
    /// (typically an ISO/ANSI minutiae template) — never a plain image, so it's
    /// compact and works with the SDK's match function.
    /// </summary>
    public class FingerprintUser
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public byte[] Template { get; set; }
        public DateTime EnrolledOn { get; set; }
    }
}
