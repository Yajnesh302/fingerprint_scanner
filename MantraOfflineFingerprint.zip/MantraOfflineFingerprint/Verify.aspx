<%@ Page Title="Verify" Language="C#" AutoEventWireup="true" CodeBehind="Verify.aspx.cs" Inherits="MantraOfflineFingerprint.Verify" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Verify Fingerprint</title>
</head>
<body style="font-family:Segoe UI, Arial; max-width:480px; margin:60px auto;">
    <form id="form1" runat="server">
        <h2>Verify a fingerprint</h2>
        <p>Place a finger on the scanner and click Verify. The app will check it against
           every enrolled user and tell you who matched.</p>

        <asp:Button ID="btnVerify" runat="server" Text="Place finger and Verify"
            OnClick="btnVerify_Click" />

        <p>
            <asp:Label ID="lblResult" runat="server" Font-Bold="true" Font-Size="Larger" />
        </p>

        <p><a href="Enroll.aspx">&laquo; Back to Enroll page</a></p>
    </form>
</body>
</html>
