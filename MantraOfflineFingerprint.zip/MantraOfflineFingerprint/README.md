# Offline Fingerprint Enroll/Verify — ASP.NET WebForms + Mantra MFS100

Kiosk-style setup: the WebForms app and the MFS100 scanner live on the **same PC**.
IIS calls the Mantra SDK directly in the code-behind — no internet, no RD Service,
no external server involved anywhere.

---

## 1. Packages / files you need to copy to the offline PC

Copy an internet-connected PC's downloads over to the company PC (USB stick is fine).

### A. Mantra MFS100 **SDK** (not just the driver you already installed)
On mantratec.com, the driver-only download (`/Download/User`) does NOT include what you
need to write custom code. Look for a separate **"SDK" / "Developer"** download section
(sometimes bundled as `MFS100_SDK_vX.X.zip` or inside the driver installer's `SDK` folder,
e.g. under wherever it installed, commonly:
`C:\Program Files\Mantra\MFS100\Driver\...\SDK\CSharp`).

From that SDK package you need these files (copy them all into your project's `bin` folder):
- `MFS100Wrapper.dll`  ← the managed .NET wrapper you'll reference in code
- `MFS100.dll`
- `mfs100api.dll`
- `libusb0.dll` (or similarly named native USB helper — whatever ships alongside)
- Any `.chm` help file or **sample project** included — **keep this**, it has the exact
  method/property names for *your* SDK version (Mantra has changed these across
  versions, see note in `App_Code/MantraDevice.cs`).

Since your Mantra **test application already captures fingerprints successfully**, the
SDK/wrapper is already present somewhere on that PC — search for `MFS100Wrapper.dll`
under `C:\Program Files\Mantra\` or wherever the test app was installed, and grab it
from there if you can't find a separate SDK zip.

### B. LiteDB (pure offline, single DLL, no native/VC++ dependencies)
Used to store enrolled names + fingerprint templates locally (a file under `App_Data`).
On a PC with internet:
```
Install-Package LiteDB -Version 5.0.17
```
Then copy `LiteDB.dll` from `packages\LiteDB.5.0.17\lib\net45\LiteDB.dll` (or the
`.nupkg`'s lib folder) into your project's `bin` folder / add as a reference.
(LiteDB is plain C#, so bitness is not an issue — only the Mantra DLLs are 32-bit.)

### C. .NET Framework 4.7.2 (or whatever the Mantra wrapper targets)
WebForms here targets classic .NET Framework, not .NET Core/5+/8 — the Mantra
wrapper is a classic COM/Interop-style DLL and does not work under modern .NET.
Confirm Visual Studio's offline install already has this — it usually does by default.

---

## 2. IIS configuration (do this — it's the #1 cause of silent failures)

The Mantra wrapper is **32-bit only**. If your app pool runs 64-bit, calls into it throw
`BadImageFormatException` or just silently fail.

1. Open **IIS Manager** → **Application Pools**
2. Select the app pool for this site → **Advanced Settings**
3. Set **Enable 32-Bit Applications = True**
4. Recycle the app pool

Also confirm in Services (`services.msc`) that the Mantra client service (something like
**MFS100ClientService**) is **Running** — the driver installer sets this up, but it's
worth checking after a reboot.

---

## 3. Project files in this package

```
MantraOfflineFingerprint/
├── App_Code/
│   ├── FingerprintUser.cs     # simple model: Id, Name, Template bytes
│   ├── FingerprintStore.cs    # LiteDB read/write helpers
│   └── MantraDevice.cs        # thin wrapper around MFS100Wrapper.dll — SEE NOTE BELOW
├── App_Data/                  # fingerprints.db will be created here automatically
├── Enroll.aspx / .aspx.cs     # asks for a name, captures + stores a fingerprint
├── Verify.aspx  / .aspx.cs    # captures a fingerprint, matches against all stored users
└── Web.config
```

---

## 4. IMPORTANT — about `MantraDevice.cs`

Mantra has changed the exact class/method/property names of `MFS100Wrapper.dll` across
SDK versions (`Init()` vs `MFS100Init()`, `IsoTemplate` vs `ISOTemplateBuffer`, etc.),
and I can't inspect the exact DLL on your PC from here. I've written `MantraDevice.cs`
using the most common, widely-used version of this API, with the **two calls that
vary by SDK version clearly marked with `// TODO`.**

Fastest way to confirm the exact names for your copy of the DLL:
- Open `MFS100Wrapper.dll` in a free .NET decompiler like **ILSpy** or **dotPeek**
  (download once while online, works fully offline afterward) and look at the
  `MFS100` class's public methods/properties, **or**
- Open the sample project that shipped in your SDK zip — copy the exact method calls
  it uses for "capture" and paste them into the marked spots in `MantraDevice.cs`.

Everything else (the enroll/verify pages, LiteDB storage, matching loop) will work
as-is once those two call sites match your DLL.

---

## 5. How verify works

There's no built-in Windows "look up by fingerprint" — the SDK gives you two things:
1. A capture call that returns a **template** (a byte array representing the print).
2. A **match/compare function** that takes two templates and returns a similarity score.

So "Verify" in this app:
1. Captures a fresh template from whoever places their finger.
2. Loops over every stored user's template and calls the match function against each.
3. Picks the highest score; if it's above a threshold (default 60, tune this once you
   test with your device), that user is the match. Otherwise → "not recognized".

This is fine for a handful of test users. If you later store hundreds/thousands of
templates, you'd want the SDK's 1:N identify function directly (if your SDK exposes one)
instead of looping — same idea, just faster.
