using System;
using System.Drawing;

namespace MantraOfflineFingerprint
{
    public partial class Enroll : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        protected void btnCapture_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            if (string.IsNullOrEmpty(name))
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Enter a name first.";
                return;
            }

            try
            {
                using (var device = new MantraDevice())
                {
                    var result = device.Capture(timeoutSeconds: 10);

                    if (!result.Success)
                    {
                        lblStatus.ForeColor = Color.Red;
                        lblStatus.Text = "Capture failed: " + result.ErrorMessage;
                        return;
                    }

                    FingerprintStore.SaveUser(name, result.Template);

                    lblStatus.ForeColor = Color.Green;
                    lblStatus.Text = string.Format(
                        "Enrolled '{0}' successfully (quality: {1}).", name, result.Quality);

                    txtName.Text = string.Empty;
                }
            }
            catch (Exception ex)
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = "Error: " + ex.Message;
            }

            BindGrid();
        }

        private void BindGrid()
        {
            gvUsers.DataSource = FingerprintStore.GetAllUsers();
            gvUsers.DataBind();
        }
    }
}
